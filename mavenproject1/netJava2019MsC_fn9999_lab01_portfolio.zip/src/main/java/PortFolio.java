import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class PortFolio {

    public static void main(String[] args) {
 
		try {
		File file = new File("READ ME.txt");
        
		if(!file.exists()) {
				file.createNewFile();	
		}
		
                    try (PrintWriter pw = new PrintWriter(file)) {
                        pw.println("Name: Penko Kanev");
                        pw.println("E-mail: 33.penko@abv.bg");
                        pw.println("RSMT First Year");
                        pw.println("Interests: Electronics, Java, C#, HTML, CSS, JS");
                        pw.close();
                    }
		System.out.println("Done");
		} catch (IOException e) {
                                        }
    }
}